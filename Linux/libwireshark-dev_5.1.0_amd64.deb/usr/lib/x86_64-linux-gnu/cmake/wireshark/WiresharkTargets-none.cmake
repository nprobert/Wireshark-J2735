#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "epan" for configuration "None"
set_property(TARGET epan APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(epan PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "wiretap"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwireshark.so.0.0.0"
  IMPORTED_SONAME_NONE "libwireshark.so.0"
  )

list(APPEND _cmake_import_check_targets epan )
list(APPEND _cmake_import_check_files_for_epan "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwireshark.so.0.0.0" )

# Import target "wiretap" for configuration "None"
set_property(TARGET wiretap APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(wiretap PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwiretap.so.0.0.0"
  IMPORTED_SONAME_NONE "libwiretap.so.0"
  )

list(APPEND _cmake_import_check_targets wiretap )
list(APPEND _cmake_import_check_files_for_wiretap "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwiretap.so.0.0.0" )

# Import target "wsutil" for configuration "None"
set_property(TARGET wsutil APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(wsutil PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwsutil.so.0.0.0"
  IMPORTED_SONAME_NONE "libwsutil.so.0"
  )

list(APPEND _cmake_import_check_targets wsutil )
list(APPEND _cmake_import_check_files_for_wsutil "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libwsutil.so.0.0.0" )

# Import target "uiqt_plugin" for configuration "None"
set_property(TARGET uiqt_plugin APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(uiqt_plugin PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libuiqt_plugin.so.0.0.0"
  IMPORTED_SONAME_NONE "libuiqt_plugin.so.0"
  )

list(APPEND _cmake_import_check_targets uiqt_plugin )
list(APPEND _cmake_import_check_files_for_uiqt_plugin "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libuiqt_plugin.so.0.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
