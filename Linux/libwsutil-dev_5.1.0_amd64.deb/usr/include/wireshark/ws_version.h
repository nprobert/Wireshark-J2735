/* ws_version.h.in */

#ifndef __WS_VERSION_H__
#define __WS_VERSION_H__

#define WIRESHARK_VERSION_MAJOR 5
#define WIRESHARK_VERSION_MINOR 1
#define WIRESHARK_VERSION_MICRO 0

#endif /* __WS_VERSION_H__ */
