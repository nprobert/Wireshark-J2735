/** @file
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 2001 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef WTAP_OPT_TYPES_H
#define WTAP_OPT_TYPES_H

#include "ws_symbol_export.h"

#include <wsutil/inet_addr.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*
 * We use the pcapng option codes for option type values.
 */

/* Options for all blocks */
#define OPT_EOFOPT             0     /**< Appears in pcapng files, but not in blocks. */
#define OPT_COMMENT            1     /**< A UTF-8 string containing a human-readable comment. */
#define OPT_CUSTOM_STR_COPY    2988  /**< A custom option containing a UTF-8 string, copying allowed. */
#define OPT_CUSTOM_BIN_COPY    2989  /**< A custom option containing binary data, copying allowed. */
#define OPT_CUSTOM_STR_NO_COPY 19372 /**< A custom option containing a UTF-8 string, copying not allowed. */
#define OPT_CUSTOM_BIN_NO_COPY 19373 /**< A custom option containing binary data, copying not allowed. */

/* Section Header block (SHB) */
#define OPT_SHB_HARDWARE       2     /**< A UTF-8 string containing the description of the
                                       *     hardware used to create this section.
                                       */
#define OPT_SHB_OS             3     /**< A UTF-8 string containing the
                                       *     name of the operating system used to create this section.
                                       */
#define OPT_SHB_USERAPPL       4     /**< A UTF-8 string containing the
                                       *     name of the application used to create this section.
                                       */

/* Interface Description block (IDB) */
#define OPT_IDB_NAME           2     /**< A UTF-8 string containing the name
                                       *     of the device used to capture data.
                                       *     "eth0" / "\Device\NPF_{AD1CE675-96D0-47C5-ADD0-2504B9126B68}"
                                       */
#define OPT_IDB_DESCRIPTION    3     /**< A UTF-8 string containing the description
                                       *     of the device used to capture data.
                                       *     "Wi-Fi" / "Local Area Connection" /
                                       *     "Wireless Network Connection" /
                                       *     "First Ethernet Interface"
                                       */
#define OPT_IDB_IP4ADDR        4     /**< XXX: if_IPv4addr Interface network address and netmask.
                                       *     This option can be repeated multiple times within the same Interface Description Block
                                       *     when multiple IPv4 addresses are assigned to the interface.
                                       *     192 168 1 1 255 255 255 0
                                       */
#define OPT_IDB_IP6ADDR        5     /**< XXX: if_IPv6addr Interface network address and prefix length (stored in the last byte).
                                       *     This option can be repeated multiple times within the same Interface
                                       *     Description Block when multiple IPv6 addresses are assigned to the interface.
                                       *     2001:0db8:85a3:08d3:1319:8a2e:0370:7344/64 is written (in hex) as
                                       *     "20 01 0d b8 85 a3 08 d3 13 19 8a 2e 03 70 73 44 40"
                                       */
#define OPT_IDB_MACADDR        6     /**< XXX: if_MACaddr  Interface Hardware MAC address (48 bits).                             */
#define OPT_IDB_EUIADDR        7     /**< XXX: if_EUIaddr  Interface Hardware EUI address (64 bits)                              */
#define OPT_IDB_SPEED          8     /**< Interface speed (in bps). 100000000 for 100Mbps
                                       */
#define OPT_IDB_TSRESOL        9     /**< Resolution of timestamps. If the Most Significant Bit is equal to zero,
                                       *     the remaining bits indicates the resolution of the timestamp as a
                                       *     negative power of 10 (e.g. 6 means microsecond resolution, timestamps
                                       *     are the number of microseconds since 1/1/1970). If the Most Significant Bit
                                       *     is equal to one, the remaining bits indicates the resolution has a
                                       *     negative power of 2 (e.g. 10 means 1/1024 of second).
                                       *     If this option is not present, a resolution of 10^-6 is assumed
                                       *     (i.e. timestamps have the same resolution of the standard 'libpcap' timestamps).
                                       */
#define OPT_IDB_TZONE          10    /**< Time zone for GMT support.  This option has neer been specified in
                                       *     greater detail and, unless it were to identify something such as
                                       *     an IANA time zone database timezone, would be insufficient for
                                       *     converting between UTC and local time.  Therefore, it SHOULD NOT
                                       *     be used; instead, the if_iana_tzname option SHOULD be used if
                                       *     time zone information is to be specified. */
#define OPT_IDB_FILTER         11    /**< The filter (e.g. "capture only TCP traffic") used to capture traffic.
                                       *     The first byte of the Option Data keeps a code of the filter used
                                       *     (e.g. if this is a libpcap string, or BPF bytecode, and more).
                                       *     More details about this format will be presented in Appendix XXX (TODO).
                                       *     (TODO: better use different options for different fields?
                                       *     e.g. if_filter_pcap, if_filter_bpf, ...) 00 "tcp port 23 and host 10.0.0.5"
                                       */
#define OPT_IDB_OS             12    /**< A UTF-8 string containing the name of the operating system of the
                                       *     machine in which this interface is installed.
                                       *     This can be different from the same information that can be
                                       *     contained by the Section Header Block
                                       *     (Section 3.1 (Section Header Block (mandatory))) because
                                       *     the capture can have been done on a remote machine.
                                       *     "Windows XP SP2" / "openSUSE 10.2"
                                       */
#define OPT_IDB_FCSLEN         13    /**< An integer value that specified the length of the
                                       *     Frame Check Sequence (in bits) for this interface.
                                       *     For link layers whose FCS length can change during time,
                                       *     the Packet Block Flags Word can be used (see Appendix A (Packet Block Flags Word))
                                       */
#define OPT_IDB_TSOFFSET       14    /**< A 64-bit signed integer value that specifies an offset (in seconds)
                                       *     that must be added to the timestamp of each packet to obtain
                                       *     the absolute timestamp of a packet. If the option is not present,
                                       *     an offset of 0 is assumed (i.e., timestamps in blocks are absolute
                                       *     timestamps).
                                       *
                                       *     This offset is not intended to be used as an offset between local
                                       *     time and UTC; for this purpose, the if_iana_tzname option SHOULD be
                                       *     used to specify a timezone.
                                       */
#define OPT_IDB_HARDWARE       15    /**< A UTF-8 string containing the description
                                       *     of the hardware of the device used
                                       *     to capture data.
                                       *     "Broadcom NetXtreme" /
                                       *     "Intel(R) PRO/1000 MT Network Connection" /
                                       *     "NETGEAR WNA1000Mv2 N150 Wireless USB Micro Adapter"
                                       */
#define OPT_IDB_TXSPEED        16    /**< A 64-bit unsigned integer indicating the interface transmit speed in
                                       *     bits per second.
                                       */
#define OPT_IDB_RXSPEED        17    /**< A 64-bit unsigned integer indicating the interface receive speed in
                                       *     bits per second.
                                       */
#define OPT_IDB_IANA_TZNAME    18    /**< A UTF-8 string that indicates the IANA time zone database timezone name
                                       *     for the IANA database timezone in which the interface is located.
                                       */

/*
 * These are the options for an EPB, but we use them for all WTAP_BLOCK_PACKET
 */
#define OPT_PKT_FLAGS        2
#define OPT_PKT_HASH         3
#define OPT_PKT_DROPCOUNT    4
#define OPT_PKT_PACKETID     5
#define OPT_PKT_QUEUE        6
#define OPT_PKT_VERDICT      7
#define OPT_PKT_PROCIDTHRDID 8    /**< 64-bit value holding the process ID in the upper 32 bits
                                   *     and the thread ID in the lower 32 bits; 0 means that
                                   *     the ID is not available.
                                   */

/* Name Resolution Block (NRB) */
#define OPT_NS_DNSNAME       2
#define OPT_NS_DNSIP4ADDR    3
#define OPT_NS_DNSIP6ADDR    4

/* Interface Statistics Block (ISB) */
#define OPT_ISB_STARTTIME    2
#define OPT_ISB_ENDTIME      3
#define OPT_ISB_IFRECV       4
#define OPT_ISB_IFDROP       5
#define OPT_ISB_FILTERACCEPT 6
#define OPT_ISB_OSDROP       7
#define OPT_ISB_USRDELIV     8

/* Process Information Block (PIB) */
#define OPT_PIB_NAME         2   /**< Short name of the process: UTF-8 string */
#define OPT_PIB_PATH         3   /**< Full path of the executable image: UTF-8 string */
#define OPT_PIB_CMDLINE      4   /**< Command line, arguments separated by NULs: bytes */
#define OPT_PIB_PPID         5   /**< Parent process ID: 32-bit unsigned integer */
#define OPT_PIB_UID          6   /**< Numeric user ID: 32-bit unsigned integer */
#define OPT_PIB_USER         7   /**< User name or textual security identifier: UTF-8 string */
#define OPT_PIB_UUID         8   /**< UUID of the executable image: 16 bytes */
#define OPT_PIB_STARTTIME    9   /**< Process start time, in nanoseconds since the Epoch: 64-bit unsigned integer */

/* Darwin-specific options for EPB */
#define OPT_PKT_DARWIN_PIB_ID               32769   /**< 32-bit number of the Darwin PIB that describes the Process ID. */
#define	OPT_PKT_DARWIN_SVC_CODE	            32770   /**< 32-bit type of service code. */
#define OPT_PKT_DARWIN_EFFECTIVE_PIB_ID     32771   /**< 32-bit number of the Darwin PIB that describes the Effective Process ID. */
#define OPT_PKT_DARWIN_MD_FLAGS             32772   /**< 32-bit bitmask containing the packet metadata flags. */
#define OPT_PKT_DARWIN_FLOW_ID              32773   /**< 32-bit opaque flow identifier. */
#define OPT_PKT_DARWIN_TRACE_TAG            32774   /**< 16-bit opaque trace tag. */
#define OPT_PKT_DARWIN_DROP_REASON          32775   /**< 32-bit drop reason. */
#define OPT_PKT_DARWIN_DROP_LINE            32776   /**< 16-bit drop line. */
#define OPT_PKT_DARWIN_DROP_FUNC            32777   /**< NUL-terminated name of the dropping function. */
#define OPT_PKT_DARWIN_COMP_GENCNT          32778   /**< 32-bit current value of the compression generation count (epoch). */


/**
 * @brief Currently supported blocks; these are not the pcapng block type values
 * for them, they're identifiers used internally, and more than one
 * pcapng block type may use a given block type.
 *
 * Note that, in a given file format, this information won't necessarily
 * appear in the form of blocks in the file, even though they're presented
 * to the caller of libwiretap as blocks when reading and are presented
 * by the caller of libwiretap as blocks when writing.  See, for example,
 * the iptrace file format, in which the interface name is given as part
 * of the packet record header; we synthesize those blocks when reading
 * (we don't currently support writing that format, but if we did, we'd
 * get the interface name from the block and put it in the packet record
 * header).
 *
 * WTAP_BLOCK_IF_ID_AND_INFO is a block that not only gives
 * descriptive information about an interface but *also* assigns an
 * ID to the interface, so that every packet has either an explicit
 * or implicit interface ID indicating on which the packet arrived.
 *
 * It does *not* refer to information about interfaces that does not
 * allow identification of the interface on which a packet arrives
 * (I'm looking at *you*, Microsoft Network Monitor...).  Do *not*
 * indicate support for that block if your capture format merely
 * gives a list of interface information without having every packet
 * explicitly or implicitly (as in, for example, the pcapng Simple
 * Packet Block) indicate on which of those interfaces the packet
 * arrived.
 *
 * WTAP_BLOCK_PACKET (which corresponds to the Enhanced Packet Block,
 * the Simple Packet Block, and the deprecated Packet Block) is not
 * currently used; it's reserved for future use.  The same applies
 * to WTAP_BLOCK_SYSTEMD_JOURNAL_EXPORT.
 *
 * WTAP_BLOCK_FT_SPECIFIC_EVENT contains filetype-specific "events",
 * such as "carrier lost" or "moved to a new channel". The "events"
 * are commonly time-stamped.
 *
 * WTAP_BLOCK_FT_SPECIFIC_REPORT contains filetype-specific "reports"
 * such as "number of times the carrier has been lost".
 * Similarly to "events", the "reports" are commonly time-stamped;
 * in addition, the "reports" may include the "duration".
 *
 * WTAP_BLOCK_FT_SPECIFIC_INFORMATION contains filetype-specific
 * "information", which is NOT timestamped.
 *
 * The distinction between the "events", "reports" and "information"
 * is that both the "events" and "reports" describe something
 * that has happened at some point in time, whereas the "information"
 * does not have a time coordinate. Further, the "events" differ
 * from the "reports" in the significance of the time coordinate.
 * For the "events", the time stamp represents a state change,
 * so that everything that happened before the "event" is
 * qualitatively different from everything that followed.
 * On the other hand, the time coordinates of "reports"
 * do not have the same significance.
 *
 * WTAP_BLOCK_FT_SPECIFIC_INFORMATION is a block that contains
 * information
 */
typedef enum {
    WTAP_BLOCK_SECTION             = 0, /**< Section block: groups a set of blocks and carries per-section metadata (pcapng SHB) */
    WTAP_BLOCK_IF_ID_AND_INFO,          /**< Interface ID and description block: identifies a capture interface and assigns it an ID referenced by packets (pcapng IDB) */
    WTAP_BLOCK_NAME_RESOLUTION,         /**< Name resolution block: maps addresses to host names (pcapng NRB) */
    WTAP_BLOCK_IF_STATISTICS,           /**< Interface statistics block: per-interface capture counters (pcapng ISB) */
    WTAP_BLOCK_DECRYPTION_SECRETS,      /**< Decryption secrets block: embeds key material for post-capture decryption (pcapng DSB) */
    WTAP_BLOCK_PACKET,                  /**< Packet block: reserved for future use; covers EPB, SPB, and deprecated PB (not currently active) */
    WTAP_BLOCK_FT_SPECIFIC_REPORT,      /**< File-type-specific report: a timestamped summary measurement, optionally with duration (e.g. "carrier lost N times") */
    WTAP_BLOCK_FT_SPECIFIC_EVENT,       /**< File-type-specific event: a timestamped state-change occurrence (e.g. "carrier lost", "channel change") */
    WTAP_BLOCK_SYSDIG_EVENT,            /**< Sysdig event block: a system-call or kernel event record from a Sysdig capture */
    WTAP_BLOCK_META_EVENT,              /**< Meta-event block: capture-framework metadata event (e.g. Falco/Sysdig container lifecycle events) */
    WTAP_BLOCK_SYSTEMD_JOURNAL_EXPORT,  /**< systemd journal export block: reserved for future use (not currently active) */
    WTAP_BLOCK_CUSTOM,                  /**< Custom block: vendor- or application-defined block with a private PEN (pcapng CB) */
    WTAP_BLOCK_FT_SPECIFIC_INFORMATION, /**< File-type-specific information: non-timestamped static metadata with no time coordinate */
    WTAP_BLOCK_PROCESS_INFORMATION,     /**< Process information block: describes a process on the capturing host that packets are associated with (pcapng PIB) */
    MAX_WTAP_BLOCK_TYPE_VALUE           /**< Sentinel: total number of defined block type identifiers */
} wtap_block_type_t;

struct wtap_block;
typedef struct wtap_block* wtap_block_t;

typedef void (*wtap_block_create_func)(wtap_block_t block);
typedef void (*wtap_mand_free_func)(wtap_block_t block);
typedef void (*wtap_mand_copy_func)(wtap_block_t dest_block, wtap_block_t src_block);

/**
 * @brief Describes a registered pcapng block type, including its identity, human-readable metadata, lifecycle callbacks, and known options.
 */
typedef struct wtap_blocktype_t {
    wtap_block_type_t  block_type;  /**< Internal enumeration value identifying this block type. */
    const char        *name;        /**< Short programmatic name for this block type. */
    const char        *description; /**< Human-readable description of this block type, suitable for display. */
    wtap_block_create_func create;  /**< Callback invoked to allocate and initialize the mandatory data for a new block of this type. */
    wtap_mand_free_func    free_mand; /**< Callback invoked to release resources held by the mandatory data when a block is destroyed. */
    wtap_mand_copy_func    copy_mand; /**< Callback invoked to deep-copy the mandatory data when a block is duplicated. */
    GHashTable            *options;   /**< Hash table mapping option codes to their definitions for all options known to this block type. */
} wtap_blocktype_t;

/**
 * @brief A single instance of a pcapng block, holding its type descriptor, mandatory data payload, options, and reference count.
 */
struct wtap_block {
    struct wtap_blocktype_t *info;           /**< Pointer to the type descriptor that defines this block's structure and callbacks. */
    void                    *mandatory_data; /**< Opaque pointer to the block's mandatory fields, allocated and managed by @ref wtap_blocktype_t::create and @ref wtap_blocktype_t::free_mand. */
    GArray                  *options;        /**< Dynamic array of wtap_option_t entries representing the optional fields present in this block. */
    int                      ref_count;      /**< Reference count governing the lifetime of this block; the block is freed when the count reaches zero. */
#ifdef DEBUG_COUNT_REFS
    unsigned                 id;             /**< Unique numeric identifier assigned to this block instance for reference-count debugging. */
#endif
};

/**
 * Holds the required data from a WTAP_BLOCK_SECTION.
 */
typedef struct wtapng_section_mandatory_s {
    uint64_t            section_length; /**< 64-bit value specifying the length in bytes of the
                                         *     following section.
                                         *     Section Length equal -1 (0xFFFFFFFFFFFFFFFF) means
                                         *     that the size of the section is not specified
                                         *   Note: if writing to a new file, this length will
                                         *     be invalid if anything changes, such as the other
                                         *     members of this struct, or the packets written.
                                         */
} wtapng_section_mandatory_t;

/** struct holding the information to build a WTAP_BLOCK_IF_ID_AND_INFO.
 *  the interface_data array holds an array of wtap_block_t
 *  representing interfaces, one per interface.
 */
typedef struct wtapng_iface_descriptions_s {
    GArray *interface_data;
} wtapng_iface_descriptions_t;

/**
 * Holds the required data from a WTAP_BLOCK_IF_ID_AND_INFO.
 */
typedef struct wtapng_if_descr_mandatory_s {
    int                    wtap_encap;            /**< link_type translated to wtap_encap */
    uint64_t               time_units_per_second;
    int                    tsprecision;           /**< WTAP_TSPREC_ value for this interface */

    uint32_t               snap_len;

    uint8_t                num_stat_entries;
    GArray                *interface_statistics;  /**< An array holding the interface statistics from
                                                   *     pcapng ISB:s or equivalent(?)*/
} wtapng_if_descr_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_NAME_RESOLUTION.
 */
typedef struct wtapng_nrb_mandatory_s {
    GList       *ipv4_addr_list;
    GList       *ipv6_addr_list;
}  wtapng_nrb_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_IF_STATISTICS.
 */
typedef struct wtapng_if_stats_mandatory_s {
    uint32_t interface_id;
    uint32_t ts_high;
    uint32_t ts_low;
} wtapng_if_stats_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_DECRYPTION_SECRETS.
 */
typedef struct wtapng_dsb_mandatory_s {
    uint32_t               secrets_type;            /** Type of secrets stored in data (see secrets-types.h) */
    uint32_t               secrets_len;             /** Length of the secrets data in bytes */
    uint8_t               *secrets_data;            /** Buffer of secrets (not NUL-terminated) */
} wtapng_dsb_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_META_EVENT.
 */
typedef struct wtapng_meta_event_mandatory_s {
    uint32_t               mev_block_type;      /** pcapng block type of the event, e.g. BLOCK_TYPE_SYSDIG_MI */
    unsigned               mev_data_len;        /** Length of the mev data in bytes */
    uint8_t               *mev_data;            /** Buffer of mev data (not NUL-terminated) */
} wtapng_meta_event_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_PACKET.
 * This includes Enhanced Packet Block, Simple Packet Block, and the deprecated Packet Block.
 * NB. I'm not including the packet data here since Wireshark handles it in other ways.
 * If we were to add it we'd need to implement copy and free routines in wtap_opttypes.c
 */
#if 0
/* Commented out for now, there's no mandatory data that isn't handled by
 * Wireshark in other ways.
 */
typedef struct wtapng_packet_mandatory_s {
    uint32_t interface_id;
    uint32_t ts_high;
    uint32_t ts_low;
    uint32_t captured_len;
    uint32_t orig_len;
} wtapng_packet_mandatory_t;
#endif

/**
 * Holds the required data from a WTAP_BLOCK_PROCESS_INFORMATION.
 */
typedef struct wtapng_process_info_mandatory_s {
    uint32_t               process_id;      /**< Process ID assigned by the OS of the capturing host */
    uint32_t               block_type;      /**< pcapng block type in which the information was read, and
                                             *     in which it will be written again: BLOCK_TYPE_CB_COPY
                                             *     for a Wireshark custom block, BLOCK_TYPE_LEGACY_DPIB
                                             *     for a Darwin process information block; 0 if unknown
                                             */
} wtapng_process_info_mandatory_t;

/**
 * Holds the required data from a WTAP_BLOCK_FT_SPECIFIC_REPORT.
 */
typedef struct wtapng_ft_specific_mandatory_s {
    unsigned  record_type;      /* the type of record this is - file type-specific value */
} wtapng_ft_specific_mandatory_t;

/**
 * @brief Data types for option values stored within a wtap block.
 *
 * @note These are value data types, not per-option identifiers. All options
 *       sharing the same storage type (e.g. every option holding a 32-bit
 *       unsigned integer) share the same ::wtap_opttype_e value.
 */
typedef enum {
    WTAP_OPTTYPE_UINT8,          /**< Option value is an 8-bit unsigned integer */
    WTAP_OPTTYPE_UINT32,         /**< Option value is a 32-bit unsigned integer */
    WTAP_OPTTYPE_UINT64,         /**< Option value is a 64-bit unsigned integer */
    WTAP_OPTTYPE_STRING,         /**< Option value is a null-terminated UTF-8 string */
    WTAP_OPTTYPE_BYTES,          /**< Option value is an arbitrary byte array */
    WTAP_OPTTYPE_IPv4,           /**< Option value is an IPv4 address */
    WTAP_OPTTYPE_IPv6,           /**< Option value is an IPv6 address */
    WTAP_OPTTYPE_CUSTOM_STRING,  /**< Option value is a custom option with a UTF-8 string payload (pcapng CB with PEN) */
    WTAP_OPTTYPE_CUSTOM_BINARY,  /**< Option value is a custom option with a binary payload (pcapng CB with PEN) */
    WTAP_OPTTYPE_IF_FILTER,      /**< Option value is an interface capture filter (BPF or display filter string) */
    WTAP_OPTTYPE_PACKET_VERDICT, /**< Option value is a packet verdict (e.g. XDP or TC eBPF verdict) */
    WTAP_OPTTYPE_PACKET_HASH,    /**< Option value is a packet hash record (algorithm plus digest bytes) */
    WTAP_OPTTYPE_INT8,           /**< Option value is an 8-bit signed integer */
    WTAP_OPTTYPE_INT32,          /**< Option value is a 32-bit signed integer */
    WTAP_OPTTYPE_INT64,          /**< Option value is a 64-bit signed integer */
} wtap_opttype_e;

/**
 * @brief Return codes for wtap block option access and mutation operations.
 */
typedef enum {
    WTAP_OPTTYPE_SUCCESS         =  0, /**< Operation completed successfully */
    WTAP_OPTTYPE_NO_SUCH_OPTION  = -1, /**< The specified option code does not exist for this block type */
    WTAP_OPTTYPE_NOT_FOUND       = -2, /**< The option exists in the block type but no instance was found */
    WTAP_OPTTYPE_TYPE_MISMATCH   = -3, /**< The requested value type does not match the option's declared type */
    WTAP_OPTTYPE_NUMBER_MISMATCH = -4, /**< The option occurrence index is out of range */
    WTAP_OPTTYPE_ALREADY_EXISTS  = -5, /**< An instance of a single-occurrence option already exists in the block */
    WTAP_OPTTYPE_BAD_BLOCK       = -6, /**< The block reference is NULL or otherwise invalid */
    WTAP_OPTTYPE_PEN_MISMATCH    = -7, /**< The Private Enterprise Number (PEN) of a custom option does not match */
} wtap_opttype_return_val;

/* https://www.iana.org/assignments/enterprise-numbers/enterprise-numbers */
#define PEN_VCTR 46254

/**
 * @brief Holds the value of a custom string option, combining a Private Enterprise Number with its associated string payload.
 */
typedef struct custom_string_opt_s {
    uint32_t pen;    /**< IANA Private Enterprise Number (PEN) identifying the organization that defined this custom option. */
    char    *string; /**< Null-terminated string payload of this custom option, allocated by the option owner. */
} custom_string_opt_t;


/**
 * @brief Holds the raw binary payload of a custom binary option.
 */
typedef struct binary_optdata {
    size_t custom_data_len; /**< Length in bytes of the data pointed to by @ref custom_data. */
    void  *custom_data;     /**< Opaque pointer to the raw binary payload of this custom option. */
} binary_optdata_t;

/**
 * @brief Holds the value of a custom binary option, combining a Private Enterprise Number with its associated binary payload.
 */
typedef struct custom_binary_opt_s {
    uint32_t         pen;  /**< IANA Private Enterprise Number (PEN) identifying the organization that defined this custom option. */
    binary_optdata_t data; /**< Binary payload of this custom option, including its length and a pointer to the raw bytes. */
} custom_binary_opt_t;

/* Interface description data - if_filter option structure */

/**
 * @brief Berkeley Packet Filter (BPF) instruction.
 *
 * Represents a single BPF instruction used for packet filtering.
 * Each instruction includes an opcode, jump targets, and a constant.
 */
typedef struct wtap_bpf_insn_s {
    uint16_t code;  /**< BPF opcode. */
    uint8_t  jt;    /**< Jump target if true. */
    uint8_t  jf;    /**< Jump target if false. */
    uint32_t k;     /**< Constant or offset. */
} wtap_bpf_insn_t;


/**
 * @brief Type of capture filter.
 *
 * Specifies the format used to define a filter for an interface.
 */
typedef enum {
    if_filter_pcap = 0, /* pcap filter string */
    if_filter_bpf  = 1  /* BPF program */
} if_filter_type_e;

/**
 * @brief Holds the value of an interface filter option, expressed as either a pcap filter string or a compiled BPF program.
 */
typedef struct if_filter_opt_s {
    if_filter_type_e type; /**< Discriminator indicating which member of @ref data is active (filter string or BPF program). */

    /**
     * @brief The filter payload, interpreted according to @ref type.
     */
    union {
        char *filter_str; /**< Null-terminated pcap filter expression string (e.g. "tcp port 80"); active when @ref type indicates a string filter. */

        /**
         * @brief A compiled BPF filter program consisting of an array of BPF instructions.
         */
        struct wtap_bpf_insns {
            unsigned         bpf_prog_len; /**< Number of BPF instructions in the @ref bpf_prog array. */
            wtap_bpf_insn_t *bpf_prog;     /**< Pointer to the array of compiled BPF instructions. */
        } bpf_prog; /**< Compiled BPF filter program; active when @ref type indicates a BPF program filter. */
    } data;
} if_filter_opt_t;

/* Packet - packet_verdict option structure */

/**
 * @brief Discriminator tag identifying the encoding of a packet verdict option.
 */
typedef enum {
    packet_verdict_hardware       = 0, /**< Verdict encoded as a raw array of octets. */
    packet_verdict_linux_ebpf_tc  = 1, /**< Verdict encoded as a 64-bit @c TC_ACT_* value (Linux eBPF TC). */
    packet_verdict_linux_ebpf_xdp = 2  /**< Verdict encoded as a 64-bit @c xdp_action value (Linux eBPF XDP). */
} packet_verdict_type_e;


/**
 * @brief Packet verdict option value, carrying a type-tagged verdict from the capture source.
 */
typedef struct packet_verdict_opt_s {
    packet_verdict_type_e type; /**< Encoding type of the verdict; selects the active @c data member. */
    union {
        GByteArray *verdict_bytes;        /**< Raw hardware verdict bytes (when @c type == @c packet_verdict_hardware). */
        uint64_t    verdict_linux_ebpf_tc; /**< Linux eBPF TC action value (when @c type == @c packet_verdict_linux_ebpf_tc). */
        uint64_t    verdict_linux_ebpf_xdp; /**< Linux eBPF XDP action value (when @c type == @c packet_verdict_linux_ebpf_xdp). */
    }               data;       /**< Verdict payload; active member selected by @c type. */
} packet_verdict_opt_t;


/**
 * @brief Packet hash option value, carrying a typed digest of the packet contents.
 */
typedef struct packet_hash_opt_s {
    uint8_t     type;        /**< Hash algorithm identifier (e.g. 2 = MD5, 3 = SHA-1, 4 = SHA-256). */
    GByteArray *hash_bytes;  /**< Raw digest bytes produced by the specified hash algorithm. */
} packet_hash_opt_t;


/**
 * @brief Discriminated union holding the value of any Wiretap option type.
 *
 * Exactly one member is valid per option instance, determined by the
 * accompanying option code and its registered value type.
 */
typedef union {
    uint8_t              uint8val;           /**< Unsigned 8-bit integer option value. */
    uint32_t             uint32val;          /**< Unsigned 32-bit integer option value. */
    uint64_t             uint64val;          /**< Unsigned 64-bit integer option value. */
    int8_t               int8val;            /**< Signed 8-bit integer option value. */
    int32_t              int32val;           /**< Signed 32-bit integer option value. */
    int64_t              int64val;           /**< Signed 64-bit integer option value. */
    ws_in4_addr          ipv4val;            /**< IPv4 address option value (network byte order). */
    ws_in6_addr          ipv6val;            /**< IPv6 address option value. */
    char                *stringval;          /**< Null-terminated UTF-8 string option value. */
    GBytes              *byteval;            /**< Arbitrary binary blob option value. */
    custom_string_opt_t  custom_stringval;   /**< Custom pen-specific string option value. */
    custom_binary_opt_t  custom_binaryval;   /**< Custom pen-specific binary option value. */
    if_filter_opt_t      if_filterval;       /**< Interface capture filter option value. */
    packet_verdict_opt_t packet_verdictval;  /**< Packet verdict option value. */
    packet_hash_opt_t    packet_hash;        /**< Packet hash/digest option value. */
} wtap_optval_t;

/**
 * @brief Represents a single option instance within a pcapng block, pairing an option code with its value.
 */
typedef struct {
    unsigned      option_id; /**< Option code identifying the type of this option within its enclosing block type. */
    wtap_optval_t value;     /**< Union holding the typed value of this option, interpreted according to the option's registered data type. */
} wtap_option_t;

/**
 * @brief Callback invoked to allocate and initialize the mandatory data for a newly created block.
 * @param block The block instance whose mandatory data is to be initialized.
 */
typedef void (*wtap_block_create_func)(wtap_block_t block);

/**
 * @brief Callback invoked to release resources held by a block's mandatory data during destruction.
 * @param block The block instance whose mandatory data is to be freed.
 */
typedef void (*wtap_mand_free_func)(wtap_block_t block);

/**
 * @brief Callback invoked to deep-copy mandatory data from one block into another.
 * @param dest_block The destination block that receives the copied mandatory data.
 * @param src_block  The source block whose mandatory data is to be copied.
 */
typedef void (*wtap_mand_copy_func)(wtap_block_t dest_block, wtap_block_t src_block);

/**
 * @brief Describes a registered option type, including its identity, human-readable metadata, data type, and behavioral flags.
 */
typedef struct {
    const char    *name;        /**< Short programmatic name for this option type, used for lookup and identification. */
    const char    *description; /**< Human-readable description of this option type, suitable for display. */
    wtap_opttype_e data_type;   /**< Enumerated data type of this option's value, used to select the correct @ref wtap_optval_t union member. */
    unsigned       flags;       /**< Bitmask of option behavioral flags (e.g. whether multiple instances of this option are permitted). */
} wtap_opttype_t;

#define GET_OPTION_TYPE(options, option_id) \
    (const wtap_opttype_t *)g_hash_table_lookup((options), GUINT_TO_POINTER(option_id))

/**
 * @brief Initialize block types.
 *
 * This is currently just a placeholder as nothing needs to be
 * initialized yet.  Should handle "registration" when code is
 * refactored to do so.
 */
WS_DLL_PUBLIC void
wtap_opttypes_initialize(void);

/**
 * @brief Create a block by type
 *
 * Return a newly allocated block with default options provided
 *
 * @param[in] block_type Block type to be created
 * @return Newly allocated block
 */
WS_DLL_PUBLIC wtap_block_t
wtap_block_create(wtap_block_type_t block_type);

/**
 * @brief Increase reference count of a block
 *
 * Call when taking a copy of a block
 *
 * @param[in] block Block add ref to
 * @return The block
 */
WS_DLL_PUBLIC wtap_block_t
wtap_block_ref(wtap_block_t block);

/**
 * @brief Decrease reference count of a block
 *
 * Needs to be called on any block once you're done with it
 *
 * @param[in] block Block to be deref'd
 */
WS_DLL_PUBLIC void
wtap_block_unref(wtap_block_t block);

/**
 * @brief Free an array of blocks
 *
 * Needs to be called to clean up blocks allocated
 * through GArray (for multiple blocks of same type)
 * Includes freeing the GArray
 *
 * @param[in] block_array Array of blocks to be freed
 */
WS_DLL_PUBLIC void
wtap_block_array_free(GArray* block_array);

/**
 * @brief Decrement the reference count of an array of blocks
 *
 * Decrement the reference count of each block in the array
 * and the GArray itself. Any element whose reference count
 * drops to 0 will be freed. If the GArray and every block
 * has a reference count of 1, this is the same as
 * wtap_block_array_free().
 *
 * @param[in] block_array Array of blocks to be dereferenced
 */
WS_DLL_PUBLIC void
wtap_block_array_unref(GArray* block_array);

/**
 * @brief Increment the reference count of an array of blocks
 *
 * Increment the reference count of each block in the array
 * and the GArray itself.
 *
 * @param[in] block_array Array of blocks to be referenced
 */
WS_DLL_PUBLIC void
wtap_block_array_ref(GArray* block_array);

/**
 * @brief Register a block type handler
 *
 * @param[in] blocktype Block type to be registered
 */
WS_DLL_PUBLIC void
wtap_opttype_block_register(wtap_blocktype_t* blocktype);

/**
 * @brief Provide type of a block
 *
 * @param[in] block Block from which to retrieve mandatory data
 * @return Block type.
 */
WS_DLL_PUBLIC wtap_block_type_t
wtap_block_get_type(wtap_block_t block);

/**
 * @brief Provide mandatory data of a block
 *
 * @param[in] block Block from which to retrieve mandatory data
 * @return Block mandatory data.  Structure varies based on block type
 */
WS_DLL_PUBLIC void*
wtap_block_get_mandatory_data(wtap_block_t block);

/**
 * @brief Count the number of times the given option appears in the block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @return unsigned - the number of times the option was found
 */
WS_DLL_PUBLIC unsigned
wtap_block_count_option(wtap_block_t block, unsigned option_id);

/**
 * @brief Add UINT8 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_uint8_option(wtap_block_t block, unsigned option_id, uint8_t value);

/**
 * @brief Set UINT8 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_uint8_option_value(wtap_block_t block, unsigned option_id, uint8_t value);

/**
 * @brief Get UINT8 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_uint8_option_value(wtap_block_t block, unsigned option_id, uint8_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add UINT32 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_uint32_option(wtap_block_t block, unsigned option_id, uint32_t value);

/**
 * @brief Set UINT32 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_uint32_option_value(wtap_block_t block, unsigned option_id, uint32_t value);

/**
 * @brief Get UINT32 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_uint32_option_value(wtap_block_t block, unsigned option_id, uint32_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add UINT64 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_uint64_option(wtap_block_t block, unsigned option_id, uint64_t value);

/**
 * @brief Set UINT64 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_uint64_option_value(wtap_block_t block, unsigned option_id, uint64_t value);

/**
 * @brief Get UINT64 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_uint64_option_value(wtap_block_t block, unsigned option_id, uint64_t* value) G_GNUC_WARN_UNUSED_RESULT;

/** Get nth UINT64 option value in a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_nth_uint64_option_value(wtap_block_t block, unsigned option_id, unsigned idx, uint64_t *value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add INT8 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_int8_option(wtap_block_t block, unsigned option_id, int8_t value);

/**
 * @brief Set INT8 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_int8_option_value(wtap_block_t block, unsigned option_id, int8_t value);

/**
 * @brief Get INT8 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_int8_option_value(wtap_block_t block, unsigned option_id, int8_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add INT32 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_int32_option(wtap_block_t block, unsigned option_id, int32_t value);

/**
 * @brief Set INT32 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_int32_option_value(wtap_block_t block, unsigned option_id, int32_t value);

/**
 * @brief Get INT32 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_int32_option_value(wtap_block_t block, unsigned option_id, int32_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add INT64 option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_int64_option(wtap_block_t block, unsigned option_id, int64_t value);

/**
 * @brief Set INT64 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_int64_option_value(wtap_block_t block, unsigned option_id, int64_t value);

/**
 * @brief Get INT64 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_int64_option_value(wtap_block_t block, unsigned option_id, int64_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add IPv4 address option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_ipv4_option(wtap_block_t block, unsigned option_id, uint32_t value);

/**
 * @brief Set IPv4 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_ipv4_option_value(wtap_block_t block, unsigned option_id, uint32_t value);

/**
 * @brief Get IPv4 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_ipv4_option_value(wtap_block_t block, unsigned option_id, uint32_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add IPv6 address option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_ipv6_option(wtap_block_t block, unsigned option_id, ws_in6_addr *value);

/**
 * @brief Set IPv6 option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_ipv6_option_value(wtap_block_t block, unsigned option_id, ws_in6_addr *value);

/**
 * @brief Get IPv6 option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_ipv6_option_value(wtap_block_t block, unsigned option_id, ws_in6_addr* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add a string option to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @param[in] value_length Maximum length of string to copy.
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_string_option(wtap_block_t block, unsigned option_id, const char *value, size_t value_length);

/**
 * @brief Add a string option to a block taking ownership of the null-terminated string.
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful (caller no longer owns @p value),
 * error code otherwise (caller still owns @p value)
 * @note To avoid memory leaks, the caller @b must examine the return status to determine ownership of @p value.
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_string_option_owned(wtap_block_t block, unsigned option_id, char *value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add a string option to a block with a printf-formatted string as its value
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] format printf-like format string
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_string_option_format(wtap_block_t block, unsigned option_id, const char *format, ...)
                                    G_GNUC_PRINTF(3,4);

/**
 * @brief Set string option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @param[in] value_length Maximum length of string to copy.
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_string_option_value(wtap_block_t block, unsigned option_id, const char* value, size_t value_length);

/**
 * @brief Set string option value for the nth instance of a particular option
 * in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[in] value New value of option
 * @param[in] value_length Maximum length of string to copy.
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_nth_string_option_value(wtap_block_t block, unsigned option_id, unsigned idx, const char* value, size_t value_length);

/**
 * @brief Set string option value in a block to a printf-formatted string
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] format printf-like format string
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_string_option_value_format(wtap_block_t block, unsigned option_id, const char *format, ...)
                                          G_GNUC_PRINTF(3,4);

/**
 * @brief Set string option value for the nth instance of a particular option
 * in a block to a printf-formatted string
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[in] format printf-like format string
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_nth_string_option_value_format(wtap_block_t block, unsigned option_id, unsigned idx, const char *format, ...)
                                              G_GNUC_PRINTF(4,5);

/**
 * @brief Get string option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_string_option_value(wtap_block_t block, unsigned option_id, char** value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Get string option value for the nth instance of a particular option
 * in a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_nth_string_option_value(wtap_block_t block, unsigned option_id, unsigned idx, char** value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add a bytes option to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option to copy
 * @param[in] value_length Number of bytes to copy
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_bytes_option(wtap_block_t block, unsigned option_id, const uint8_t *value, size_t value_length);

/**
 * @brief Add a bytes option to a block, borrowing the value from a GBytes
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option as a GBytes
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_bytes_option_borrow(wtap_block_t block, unsigned option_id, GBytes *value);

/**
 * @brief Set bytes option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @param[in] value_length Number of bytes to copy.
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_bytes_option_value(wtap_block_t block, unsigned option_id, const uint8_t* value, size_t value_length);

/**
 * @brief Set bytes option value for nth instance of a particular option in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_nth_bytes_option_value(wtap_block_t block, unsigned option_id, unsigned idx, GBytes* value);

/**
 * @brief Get bytes option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 * @note You should call g_bytes_ref() on value if you plan to keep it around
 * (and then g_bytes_unref() when you're done with it).
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_bytes_option_value(wtap_block_t block, unsigned option_id, GBytes** value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Get bytes option value for nth instance of a particular option in a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 * @note You should call g_bytes_ref() on value if you plan to keep it around
 * (and then g_bytes_unref() when you're done with it).
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_nth_bytes_option_value(wtap_block_t block, unsigned option_id, unsigned idx, GBytes** value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add a string custom option, with a particular Private Enterprise
 * Number, to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] pen Private Enterprise Number value for option
 * @param[in] value Value of option
 * @param[in] value_length Maximum length of string to copy.
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_custom_string_option(wtap_block_t block, unsigned option_id, uint32_t pen, const char *value, size_t value_length);

/**
 * @brief Add a binary custom option, with a particular Private Enterprise
 * Number, to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] pen Private Enterprise Number value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_custom_binary_option(wtap_block_t block, unsigned option_id, uint32_t pen, binary_optdata_t *value);

/**
 * @brief Add a binary custom option, with a particular Private Enterprise
 * Number, to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] pen Private Enterprise Number value for option
 * @param[in] data Raw data of option
 * @param[in] data_size Size of raw data
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_custom_binary_option_from_data(wtap_block_t block, unsigned option_id, uint32_t pen, const void *data, size_t data_size);

/**
 * @brief Get binary custom option value for the nth instance of a particular option,
 * with a particular Private Enterprise Number, in a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[in] pen Private Enterprise Number value for option
 * @param[in] idx Instance number of option with that ID
 * @param[out] value Returned value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_nth_custom_binary_option_value(wtap_block_t block, unsigned option_id, uint32_t pen, unsigned idx, binary_optdata_t *value);

/**
 * @brief Add an if_filter option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_if_filter_option(wtap_block_t block, unsigned option_id, if_filter_opt_t* value);

/**
 * @brief Set an if_filter option value in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_if_filter_option_value(wtap_block_t block, unsigned option_id, if_filter_opt_t* value);

/**
 * @brief Get an if_filter option value from a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[out] value Returned value of option value
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_if_filter_option_value(wtap_block_t block, unsigned option_id, if_filter_opt_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Add a packet_verdict option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_packet_verdict_option(wtap_block_t block, unsigned option_id, packet_verdict_opt_t* value);

/**
 * @brief Set packet_verdict option value for the nth instance of a particular
 * option in a block
 *
 * @param[in] block Block in which to set the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[in] value New value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_set_nth_packet_verdict_option_value(wtap_block_t block, unsigned option_id, unsigned idx, packet_verdict_opt_t* value);

/**
 * @brief Get packet_verdict option value for the nth instance of a particular
 * option in a block
 *
 * @param[in] block Block from which to get the option value
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @param[out] value Returned value of option value
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_get_nth_packet_verdict_option_value(wtap_block_t block, unsigned option_id, unsigned idx, packet_verdict_opt_t* value) G_GNUC_WARN_UNUSED_RESULT;

/**
 * @brief Free a packet verdict option value
 *
 * @param[in] verdict Pointer to the packet verdict option to free
 */
WS_DLL_PUBLIC void
wtap_packet_verdict_free(packet_verdict_opt_t* verdict);

/**
 * @brief Add a packet_hash option value to a block
 *
 * @param[in] block Block to which to add the option
 * @param[in] option_id Identifier value for option
 * @param[in] value Value of option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_add_packet_hash_option(wtap_block_t block, unsigned option_id, packet_hash_opt_t* value);

/**
 * @brief Frees memory allocated for a packet hash option.
 *
 * @param hash Pointer to the packet hash option to be freed.
 */
WS_DLL_PUBLIC void
wtap_packet_hash_free(packet_hash_opt_t* hash);

/**
 * @brief Remove an option from a block
 *
 * @param[in] block Block from which to remove the option
 * @param[in] option_id Identifier value for option
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_remove_option(wtap_block_t block, unsigned option_id);

/**
 * @brief Remove the nth instance of an option from a block
 *
 * @param[in] block Block from which to remove the option instance
 * @param[in] option_id Identifier value for option
 * @param[in] idx Instance number of option with that ID
 * @return wtap_opttype_return_val - WTAP_OPTTYPE_SUCCESS if successful,
 * error code otherwise
 */
WS_DLL_PUBLIC wtap_opttype_return_val
wtap_block_remove_nth_option_instance(wtap_block_t block, unsigned option_id, unsigned idx);

/**
 * @brief Copy a block to another.
 *
 * Any options that are in the destination but not the source are not removed.
 * Options that are just in source will be added to destination
 *
 * @param[in] dest_block Block to be copied to
 * @param[in] src_block Block to be copied from
 */
WS_DLL_PUBLIC void
wtap_block_copy(wtap_block_t dest_block, wtap_block_t src_block);

/**
 * @brief Make a copy of a block.
 *
 * @param[in] block Block to be copied from
 * @return Newly allocated copy of that block
 */
WS_DLL_PUBLIC wtap_block_t
wtap_block_make_copy(wtap_block_t block);

/**
 * @typedef wtap_block_foreach_func
 * @brief Callback type for iterating over block options.
 *
 * Called once for each option in a block. Returning false stops iteration.
 *
 * @param block The block being inspected.
 * @param option_id The ID of the current option.
 * @param option_type The type of the option.
 * @param option Pointer to the option value.
 * @param user_data User-defined context passed to the callback.
 * @return true to continue iteration; false to stop.
 */
typedef bool (*wtap_block_foreach_func)(wtap_block_t block, unsigned option_id,
                                        wtap_opttype_e option_type, wtap_optval_t *option,
                                        void *user_data);

/**
 * @brief Iterate over all options in a block.
 *
 * Invokes the given callback for each option in the block. Stops early if the callback returns false.
 *
 * @param block The block to inspect.
 * @param func Callback to invoke for each option.
 * @param user_data User-defined context passed to the callback.
 * @return true if all options were visited; false if iteration was stopped early.
 */
WS_DLL_PUBLIC bool
wtap_block_foreach_option(wtap_block_t block, wtap_block_foreach_func func, void* user_data);

/**
 * @brief Cleanup the internal structures
 */
WS_DLL_PUBLIC void
wtap_opttypes_cleanup(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* WTAP_OPT_TYPES_H */
